function placeBid(item) {
    alert('You placed a bid for ' + item);
    // Hier kun je logica toevoegen om het bieden te verwerken, zoals het weergeven van een formulier of een melding.
}

let slideIndex = [];

function showSlides(n, item) {
    let i;
    let slides = document.getElementsByClassName("mySlides");
    if (!slideIndex[item]) {
        slideIndex[item] = 1;
    }
    slideIndex[item] += n;
    if (slideIndex[item] > slides.length) {slideIndex[item] = 1}
    if (slideIndex[item] < 1) {slideIndex[item] = slides.length}
    for (i = 0; i < slides.length; i++) {
        slides[i].style.display = "none";
    }
    slides[slideIndex[item]-1].style.display = "block";
}

function plusSlides(n, item) {
    showSlides(n, item);
}

document.addEventListener('DOMContentLoaded', function() {
    const dropbtn = document.querySelector('.dropbtn');
    const dropdownContent = document.querySelector('.dropdown-content');

    dropbtn.addEventListener('click', function() {
        dropdownContent.classList.toggle('show');
    });

    window.onclick = function(event) {
        if (!event.target.matches('.dropbtn')) {
            if (dropdownContent.classList.contains('show')) {
                dropdownContent.classList.remove('show');
            }
        }
    };

    const buttons = document.querySelectorAll('.buy-btn, .bid-btn');
    buttons.forEach(button => {
        button.addEventListener('mouseenter', function() {
            this.style.transform = 'scale(1.1)';
            this.style.transition = 'transform 0.3s ease';
        });
        button.addEventListener('mouseleave', function() {
            this.style.transform = 'scale(1)';
        });
    });

    const productImages = document.querySelectorAll('.product img');
    productImages.forEach(image => {
        image.addEventListener('mouseenter', function() {
            this.style.transform = 'scale(1.1)';
            this.style.transition = 'transform 0.3s ease';
        });
        image.addEventListener('mouseleave', function() {
            this.style.transform = 'scale(1)';
        });
    });
});



    // Elements
    const openButton = document.querySelector('.openSlideOver');
    const closeButton = document.querySelector('.relative -m-2 p-2');
    const backdrop = document.querySelector('.fixed.inset-0.bg-gray-500');
    const slideover = document.querySelector('.pointer-events-auto.w-screen.max-w-md');



    // Event Listeners
    if (openButton) {
        openButton.addEventListener('click', openSlideOver);
    }

    if (closeButton) {
        closeButton.addEventListener('click', closeSlideOver);
    }

    if (backdrop) {
        backdrop.addEventListener('click', closeSlideOver);
    }

    document.addEventListener('keydown', function(event) {
        if (event.key === 'Escape') {
            closeSlideOver();
        }
    });

    // Functions
    function openSlideOver() {
        // Select the slide-over panel
        const slideOverPanel = document.querySelector('.fixed.inset-0.overflow-hidden');
        // Select the backdrop
        const backdrop = document.querySelector('.fixed.inset-0.bg-gray-500.bg-opacity-75');
    
        // Check if elements exist before trying to change their styles
        if (slideOverPanel) {
            slideOverPanel.style.display = 'block';
        }
        if (backdrop) {
            backdrop.style.display = 'block';
        }
    }


    function closeSlideOver() {
        // Select the slide-over panel
        const slideOverPanel = document.querySelector('.fixed.inset-0.overflow-hidden');
        // Select the backdrop
        const backdrop = document.querySelector('.fixed.inset-0.bg-gray-500.bg-opacity-75');
    
        // Check if elements exist before trying to change their styles
        if (slideOverPanel) {
            slideOverPanel.style.display = 'none';
        }
        if (backdrop) {
            backdrop.style.display = 'none';
        }
    
        // Re-enable scrolling on the body
        document.body.classList.remove('overflow-hidden');
    }



document.addEventListener('DOMContentLoaded', function() {
    const dropbtn = document.querySelector('.dropbtn');
    const dropdownContent = document.querySelector('.dropdown-content');
    const navbar = document.querySelector('header');
    const sticky = navbar.offsetTop;

    function toggleStickyNavbar() {
        if (window.pageYOffset > sticky) {
            navbar.classList.add('sticky', 'navbar-scrolled');
        } else {
            navbar.classList.remove('sticky', 'navbar-scrolled');
        }
    }

    window.onscroll = function() {
        toggleStickyNavbar();
    };

    toggleStickyNavbar(); // Initial check in case the page is already scrolled


    dropbtn.addEventListener('click', function(event) {
        toggleDropdown(event); // Pass the event object to toggleDropdown
        event.stopPropagation();
    });

    // Prevent clicks within the dropdown from closing it
    dropdownContent.addEventListener('click', function(event) {
        event.stopPropagation(); // Stop click from propagating to document
    });

    function toggleDropdown(event) {
        // Toggle the display state of the dropdown content
        if (dropdownContent.style.display === "none" || !dropdownContent.style.display) {
            dropdownContent.style.display = "block";
            // Use setPointerCapture to ensure all pointer events are directed to this element
            if (event && event.target.setPointerCapture) {
                event.target.setPointerCapture(event.pointerId);
            }
        } else {
            dropdownContent.style.display = "none";
            // Release pointer capture when closing the dropdown
            if (event && event.target.releasePointerCapture) {
                event.target.releasePointerCapture(event.pointerId);
            }
        }
    }

    
    const buttons = document.querySelectorAll('.buy-btn, .bid-btn');
    buttons.forEach(button => {
        button.addEventListener('mouseenter', function() {
            this.style.transform = 'scale(1.1)';
            this.style.transition = 'transform 0.3s ease';
        });
        button.addEventListener('mouseleave', function() {
            this.style.transform = 'scale(1)';
        });
    });
    const productImages = document.querySelectorAll('.product img');
    productImages.forEach(image => {
        image.addEventListener('mouseenter', function() {
            this.style.transform = 'scale(1.1)';
            this.style.transition = 'transform 0.3s ease';
        });
        image.addEventListener('mouseleave', function() {
            this.style.transform = 'scale(1)';
        });
    });
    closeSlideOver(); // Close the slideover when the DOM is loaded
});

// Rest of the code...
function placeBid(item) {
    alert('You placed a bid for ' + item);
    // Additional logic for placing a bid can be added here, like displaying a form or sending data to the server.
}
